<h1 align="center">💻 WorldBeauty 👩‍🦰👨‍🦱</h1>

<p align="center">
    <img alt="Java" src="https://img.shields.io/badge/java-%23ED8B00.svg?&style=for-the-badge&logo=java&logoColor=white"/>
    <img alt="Spring" src="https://img.shields.io/badge/spring-%236DB33F.svg?&style=for-the-badge&logo=spring&logoColor=white"/>
    <img alt="PostgreSQL" src="https://img.shields.io/badge/PostgreSQL-316192?style=for-the-badge&logo=postgresql&logoColor=white"/>
    <img alt="HTML5" src="https://img.shields.io/badge/HTML5-E34F26?style=for-the-badge&logo=html5&logoColor=white">
    <img alt="CSS" src="https://img.shields.io/badge/CSS3-1572B6?style=for-the-badge&logo=css3&logoColor=white">
    <img alt="Bootstrap" src="https://img.shields.io/badge/Bootstrap-563D7C?style=for-the-badge&logo=bootstrap&logoColor=white">
</p>
<p align="left">
    <img src="https://img.shields.io/badge/status-em%20desenvolvimento-blue?style=for-the-badge&logo=appveyor">
</p>

<h1 align="left"> 💡 Sobre </h1>
<p align="justify">O projeto WorldBeauty é um trabalho orientado pelo professor Gerson da Penha, da disciplina de Programação Orientada a Objetos da FATEC São José dos Campos. O projeto tem o foco de apresentar programação WEB
            utilizando tecnologias Java como Spring Boot, Hibernate e Thymeleaf.</p>
<p align="justify">

<h2>💻WorldBeauty conta com</h2>

- [x] Base de dados dos clientes
- [X] Um sistema completo e responsivo
- [ ] Análise de dados dos usuários *(TODO)*

</p>

<h2 align="left">💻Contribuidores 🧑🏾🧑🏽</h2>
<p align="justify">Desenvolvido por <a href="github.com/nicursino">Nicolas Cursino Magarifuchi</a> e <a href="github.com/medrenan">Renan Alves de Medeiros</a>
</p>